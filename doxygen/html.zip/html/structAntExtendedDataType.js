var structAntExtendedDataType =
[
    [ "s8RSSI", "structAntExtendedDataType.html#a581d4f64c672d93a6df5c63db075d492", null ],
    [ "u16DeviceID", "structAntExtendedDataType.html#a9d5bc62dc157c33e61901d8bba3f2e81", null ],
    [ "u8Channel", "structAntExtendedDataType.html#ab76fdb9425184ad2e069d74de963e98a", null ],
    [ "u8DeviceType", "structAntExtendedDataType.html#aa951e12204d5eb5dead79df31b4b8515", null ],
    [ "u8Dummy", "structAntExtendedDataType.html#a65b6c3a243ee16a4f9e7e1ec30ac28f9", null ],
    [ "u8Flags", "structAntExtendedDataType.html#a3cfe6e55cd705ff6135b763ff3c4e995", null ],
    [ "u8TransType", "structAntExtendedDataType.html#a7c58ed4e8704b69d32e45cd6c568db2e", null ]
];