var structTWIPeripheralType =
[
    [ "pBaseAddress", "structTWIPeripheralType.html#a1aba4642e7f4ecfae56c17353e45f2c8", null ],
    [ "pTransmitBuffer", "structTWIPeripheralType.html#a0c717b316d1f1c2d2329053922c7c39e", null ],
    [ "pu8RxBuffer", "structTWIPeripheralType.html#a90b4f2c98ae95b888a185b7d842f52b5", null ],
    [ "u32Flags", "structTWIPeripheralType.html#ae41fc27761c464cf4dd08e81f299d099", null ]
];