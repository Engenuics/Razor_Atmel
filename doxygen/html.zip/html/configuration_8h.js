var configuration_8h =
[
    [ "ADC_CHANNEL_ARRAY", "configuration_8h.html#a4418bbe578f1139f94d4a05b7a99b04c", null ],
    [ "ANT_SPI", "configuration_8h.html#a7afd7d310e41a8d27b399b98a0ef5d9a", null ],
    [ "ANT_SSP_FLAGS", "configuration_8h.html#ab4cf6fd05e8c448111102e35b20a9981", null ],
    [ "BLADE_SPI", "configuration_8h.html#afcc84bc67b5b5507b88ff066992db699", null ],
    [ "BLADE_UART", "configuration_8h.html#a27554eed5031295d9c4c56e78ba65787", null ],
    [ "BUTTON0", "configuration_8h.html#ac3c25392012bbb1b3dc72e9c8847c806", null ],
    [ "BUTTON1", "configuration_8h.html#a8b8426d5c8d4a02dc1b15353d4bc613d", null ],
    [ "BUTTON2", "configuration_8h.html#acad5ba277242dbcd68edaff5f550f29e", null ],
    [ "BUTTON3", "configuration_8h.html#a64f0a5235b4b24fb04f54fb437011c75", null ],
    [ "BUZZER1", "configuration_8h.html#ac2f338bf7fea5d3e0044b48bd253f3ff", null ],
    [ "BUZZER2", "configuration_8h.html#a448140fff1ac05b2ac0ee96d751bb882", null ],
    [ "DEBUG_MODE", "configuration_8h.html#ac80a3592e72fd96b772ee47a7d8e0d0a", null ],
    [ "DEBUG_UART", "configuration_8h.html#ace21428290f0e412332701391f825a10", null ],
    [ "GPIOA_BUTTONS", "configuration_8h.html#a32845cb32607ee9be55da6e568d3fc1e", null ],
    [ "GPIOB_BUTTONS", "configuration_8h.html#a0b6fc03ffbde38009736a22e4cc137ca", null ],
    [ "SD_SSP", "configuration_8h.html#aaf1edfe18cc09911129e7d32e118b11d", null ],
    [ "TOTAL_BUTTONS", "configuration_8h.html#a3af443a2f3cfadfc09f75bc764bdeccf", null ],
    [ "TOTAL_LEDS", "configuration_8h.html#a0ccf2b3db9429897fc6aaeefa659c503", null ],
    [ "PeripheralType", "configuration_8h.html#afc6e623ab05d213bda9b62f3bd823238", [
      [ "SPI", "configuration_8h.html#afc6e623ab05d213bda9b62f3bd823238aefea9eb0772378037221a3f1fe759a76", null ],
      [ "UART", "configuration_8h.html#afc6e623ab05d213bda9b62f3bd823238ab81270ba54ae4586a18415e5a579633d", null ],
      [ "USART0", "configuration_8h.html#afc6e623ab05d213bda9b62f3bd823238aec2fd83f873455753148f632d3b31853", null ],
      [ "USART1", "configuration_8h.html#afc6e623ab05d213bda9b62f3bd823238ac7a8167f83749eed87e3e9fb0dddc6cf", null ],
      [ "USART2", "configuration_8h.html#afc6e623ab05d213bda9b62f3bd823238a096356780f867794998b759a91043b45", null ],
      [ "USART3", "configuration_8h.html#afc6e623ab05d213bda9b62f3bd823238aece01379f8a2c9870feb6210f81c4edd", null ]
    ] ]
];