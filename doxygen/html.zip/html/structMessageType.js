var structMessageType =
[
    [ "psNextMessage", "structMessageType.html#a3cf7e0c78f70a803e302a2a3cd2b8baf", null ],
    [ "pu8Message", "structMessageType.html#a3e5b9bf4955b514d52807c00be5254d1", null ],
    [ "u32Size", "structMessageType.html#a1e9d88314667b1ed7c5ab9c3dad6ea4e", null ],
    [ "u32Token", "structMessageType.html#af65bf8084777eddf08ab2f1126a471f5", null ]
];