var eief1_pcb_01_8c =
[
    [ "ClockSetup", "eief1-pcb-01_8c.html#aca735570024c950fd682a96342b84a94", null ],
    [ "GpioSetup", "eief1-pcb-01_8c.html#af88ea80ebfc22fae790de9dd8db74ce9", null ],
    [ "PWMAudioOff", "eief1-pcb-01_8c.html#a7a5d534963a774979ddfd0f86a07d255", null ],
    [ "PWMAudioOn", "eief1-pcb-01_8c.html#a72d863b1026cd68cc5db962b51f7ad5d", null ],
    [ "PWMAudioSetFrequency", "eief1-pcb-01_8c.html#acbe91c762555e6835dbe770ecfce3ecd", null ],
    [ "PWMSetupAudio", "eief1-pcb-01_8c.html#a8b1e7cadaeb381e8ba677cfede840e13", null ],
    [ "RealTimeClockSetup", "eief1-pcb-01_8c.html#a786a28c1a4964ca2a3b8af5e8cfde934", null ],
    [ "SystemSleep", "eief1-pcb-01_8c.html#a9b69fd403c668b7b229fa4e71a77616a", null ],
    [ "SystemTimeCheck", "eief1-pcb-01_8c.html#afdf60ae19c97005e0b80afa7eee2e726", null ],
    [ "SysTickSetup", "eief1-pcb-01_8c.html#aebe279375f0a4bddd6a03a323821ccde", null ],
    [ "WatchDogSetup", "eief1-pcb-01_8c.html#a4352a1df62e6397cb4dfb0e66bdec1ff", null ],
    [ "G_u32ApplicationFlags", "eief1-pcb-01_8c.html#a633c00979917e136ecca6a4c6be2792d", null ],
    [ "G_u32DebugFlags", "eief1-pcb-01_8c.html#a089097107f68be64fee27f13f5da8646", null ],
    [ "G_u32SystemFlags", "eief1-pcb-01_8c.html#a8744f5867dbc6c175c029dd7ee5e70af", null ],
    [ "G_u32SystemTime1ms", "eief1-pcb-01_8c.html#aa146f1e0ff7266bfbef420b6fc072f80", null ],
    [ "G_u32SystemTime1s", "eief1-pcb-01_8c.html#a0d1ec61cf0423379d45262186ed60d9c", null ]
];