var structUartConfigurationType =
[
    [ "fnRxCallback", "structUartConfigurationType.html#a3676f6e1b38c4de853f8c12adc895075", null ],
    [ "pu8RxBufferAddress", "structUartConfigurationType.html#ad78a33f90d38bf231bf0dc0d190016b3", null ],
    [ "pu8RxNextByte", "structUartConfigurationType.html#a1b230962c18dd9d7bceac40742e28ad5", null ],
    [ "u16RxBufferSize", "structUartConfigurationType.html#ab7fc4919ed52c499554e6a111ff03385", null ],
    [ "UartPeripheral", "structUartConfigurationType.html#acfbee762a55d7d55943a96463c6ee12c", null ]
];