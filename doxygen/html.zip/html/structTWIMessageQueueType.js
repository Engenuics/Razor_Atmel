var structTWIMessageQueueType =
[
    [ "Direction", "structTWIMessageQueueType.html#a6524f7bbc2a14200c28b99f69da433a3", null ],
    [ "pu8RxBuffer", "structTWIMessageQueueType.html#a90b4f2c98ae95b888a185b7d842f52b5", null ],
    [ "Stop", "structTWIMessageQueueType.html#a10f4db6b073ce522ab9b1e0f371977cd", null ],
    [ "u32Size", "structTWIMessageQueueType.html#a1e9d88314667b1ed7c5ab9c3dad6ea4e", null ],
    [ "u8Address", "structTWIMessageQueueType.html#a90a4a09cb07d3a4d61c79d9c14a8e70e", null ],
    [ "u8Attempts", "structTWIMessageQueueType.html#a1eaa9e735c37dcd9919f1b9d37f51a0f", null ]
];