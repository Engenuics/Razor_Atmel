var annotated_dup =
[
    [ "AntApplicationMsgListType", "structAntApplicationMsgListType.html", "structAntApplicationMsgListType" ],
    [ "AntAssignChannelInfoType", "structAntAssignChannelInfoType.html", "structAntAssignChannelInfoType" ],
    [ "AntExtendedDataType", "structAntExtendedDataType.html", "structAntExtendedDataType" ],
    [ "AntMessageResponseType", "structAntMessageResponseType.html", "structAntMessageResponseType" ],
    [ "AntOutgoingMessageListType", "structAntOutgoingMessageListType.html", "structAntOutgoingMessageListType" ],
    [ "ButtonConfigType", "structButtonConfigType.html", "structButtonConfigType" ],
    [ "DebugCommandType", "structDebugCommandType.html", "structDebugCommandType" ],
    [ "LedConfigType", "structLedConfigType.html", "structLedConfigType" ],
    [ "MessageSlot", "structMessageSlot.html", "structMessageSlot" ],
    [ "MessageStatus", "structMessageStatus.html", "structMessageStatus" ],
    [ "MessageType", "structMessageType.html", "structMessageType" ],
    [ "SspConfigurationType", "structSspConfigurationType.html", "structSspConfigurationType" ],
    [ "SspPeripheralType", "structSspPeripheralType.html", "structSspPeripheralType" ],
    [ "TWIMessageQueueType", "structTWIMessageQueueType.html", "structTWIMessageQueueType" ],
    [ "TWIPeripheralType", "structTWIPeripheralType.html", "structTWIPeripheralType" ],
    [ "UartConfigurationType", "structUartConfigurationType.html", "structUartConfigurationType" ],
    [ "UartPeripheralType", "structUartPeripheralType.html", "structUartPeripheralType" ]
];