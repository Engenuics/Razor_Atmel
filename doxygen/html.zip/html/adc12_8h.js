var adc12_8h =
[
    [ "Adc12ChannelType", "adc12_8h.html#a790c54851e86de299bd6fa7a6bea616c", [
      [ "ADC12_CH0", "adc12_8h.html#a790c54851e86de299bd6fa7a6bea616ca27594de95c933adda0a8cbc09c36d9b2", null ],
      [ "ADC12_CH1", "adc12_8h.html#a790c54851e86de299bd6fa7a6bea616caa95612e540be4131a335cfd2ca8c7942", null ],
      [ "ADC12_CH2", "adc12_8h.html#a790c54851e86de299bd6fa7a6bea616cacead50b3f003ac5c312789ffe3394101", null ],
      [ "ADC12_CH3", "adc12_8h.html#a790c54851e86de299bd6fa7a6bea616ca238ddcdd98948528c8e593b188fa2d71", null ],
      [ "ADC12_CH4", "adc12_8h.html#a790c54851e86de299bd6fa7a6bea616ca03d296dc89c9aa213bca19aba12462de", null ],
      [ "ADC12_CH5", "adc12_8h.html#a790c54851e86de299bd6fa7a6bea616caffb2a9384ee65d65f0e4dd6194083143", null ],
      [ "ADC12_CH6", "adc12_8h.html#a790c54851e86de299bd6fa7a6bea616caad8060db82eff02f78b8ddbe8f0ccdfb", null ],
      [ "ADC12_CH7", "adc12_8h.html#a790c54851e86de299bd6fa7a6bea616ca13c93c50902b93422be1582dd0c66d61", null ]
    ] ],
    [ "Adc12AssignCallback", "adc12_8h.html#ac04fc02a7c0cefbfd60c84d1ab46ad8c", null ],
    [ "Adc12DefaultCallback", "adc12_8h.html#a25cb7c0849f2188502baffd0e1dcf151", null ],
    [ "Adc12Initialize", "adc12_8h.html#aff45219d6c17ab72d9da5ee791a1949b", null ],
    [ "Adc12RunActiveState", "adc12_8h.html#a78476d7727c1b7350a260d25e8d05d21", null ],
    [ "Adc12StartConversion", "adc12_8h.html#a5ec3309748518c62f918b6faf2e69511", null ],
    [ "ADCC0_IrqHandler", "adc12_8h.html#adee8b35957aea7791dc4f3ae0d97aec3", null ]
];