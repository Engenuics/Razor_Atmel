var structMessageStatus =
[
    [ "eState", "structMessageStatus.html#a3a10e813b16bd541efcb53ebcf2e796a", null ],
    [ "u32Timestamp", "structMessageStatus.html#af9cbe2c493df49eea706bf67111bc5ec", null ],
    [ "u32Token", "structMessageStatus.html#af65bf8084777eddf08ab2f1126a471f5", null ]
];