var searchData=
[
  ['clocksetup',['ClockSetup',['../eief1-pcb-01_8c.html#aca735570024c950fd682a96342b84a94',1,'ClockSetup(void):&#160;eief1-pcb-01.c'],['../eief1-pcb-01_8h.html#aca735570024c950fd682a96342b84a94',1,'ClockSetup(void):&#160;eief1-pcb-01.c']]]
];
