var searchData=
[
  ['twimessagequeuetype',['TWIMessageQueueType',['../structTWIMessageQueueType.html',1,'']]],
  ['twiperipheraltype',['TWIPeripheralType',['../structTWIPeripheralType.html',1,'']]]
];
