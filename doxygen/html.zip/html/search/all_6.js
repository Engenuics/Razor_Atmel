var searchData=
[
  ['firmware_5fversion',['FIRMWARE_VERSION',['../main_8h.html#aa14dc39d52ab121ceb570f1a265385e0',1,'main.h']]],
  ['fncode_5ftype',['fnCode_type',['../typedefs_8h.html#a8ad064e9f68a73ffceb7adad746b3d81',1,'typedefs.h']]],
  ['fncode_5fu16_5ftype',['fnCode_u16_type',['../typedefs_8h.html#adf5be79d6f4ab4b5f1364599ad961d96',1,'typedefs.h']]]
];
