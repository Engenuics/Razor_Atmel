var searchData=
[
  ['number_5fapplications',['NUMBER_APPLICATIONS',['../main_8h.html#ade12517e47f32c03f37f4bf7fb37ca1c',1,'main.h']]]
];
