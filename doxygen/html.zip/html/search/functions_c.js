var searchData=
[
  ['userapp1initialize',['UserApp1Initialize',['../user__app1_8c.html#abbe2c1447f0d62d7c9054b6331f4f0ea',1,'UserApp1Initialize(void):&#160;user_app1.c'],['../user__app1_8h.html#abbe2c1447f0d62d7c9054b6331f4f0ea',1,'UserApp1Initialize(void):&#160;user_app1.c']]],
  ['userapp1runactivestate',['UserApp1RunActiveState',['../user__app1_8c.html#a8f2ac55b4fdfdf3841ce019c51b72f5e',1,'UserApp1RunActiveState(void):&#160;user_app1.c'],['../user__app1_8h.html#a8f2ac55b4fdfdf3841ce019c51b72f5e',1,'UserApp1RunActiveState(void):&#160;user_app1.c']]]
];
