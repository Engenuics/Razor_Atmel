var searchData=
[
  ['total_5fbuttons',['TOTAL_BUTTONS',['../configuration_8h.html#a3af443a2f3cfadfc09f75bc764bdeccf',1,'configuration.h']]],
  ['total_5fleds',['TOTAL_LEDS',['../configuration_8h.html#a0ccf2b3db9429897fc6aaeefa659c503',1,'configuration.h']]],
  ['transfer_5fin_5fprogress',['TRANSFER_IN_PROGRESS',['../antdefines_8h.html#ae295711c3c6f5a87788c7dad6ef83da1',1,'antdefines.h']]],
  ['transfer_5fsequence_5fnumber_5ferror',['TRANSFER_SEQUENCE_NUMBER_ERROR',['../antdefines_8h.html#ae578b7c324f2d9addad818e1b6df7d7e',1,'antdefines.h']]]
];
