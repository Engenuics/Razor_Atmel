var searchData=
[
  ['s16',['s16',['../typedefs_8h.html#a2e9bf6983da73775aa86158c825bf777',1,'typedefs.h']]],
  ['s32',['s32',['../typedefs_8h.html#a584ab8b1fe53a7874ffa10b1f0c54ef4',1,'typedefs.h']]],
  ['s8',['s8',['../typedefs_8h.html#a151f780fb455885061d3b77ec1c90c03',1,'typedefs.h']]],
  ['sc16',['sc16',['../typedefs_8h.html#ae847bd4779c434029761bec8b0935514',1,'typedefs.h']]],
  ['sc32',['sc32',['../typedefs_8h.html#a0638a9182b1734497dbeccda3b4ead18',1,'typedefs.h']]],
  ['sc8',['sc8',['../typedefs_8h.html#ad0034305fecfbc44db47d5b7c785c2a6',1,'typedefs.h']]]
];
