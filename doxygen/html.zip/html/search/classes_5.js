var searchData=
[
  ['sspconfigurationtype',['SspConfigurationType',['../structSspConfigurationType.html',1,'']]],
  ['sspperipheraltype',['SspPeripheralType',['../structSspPeripheralType.html',1,'']]]
];
