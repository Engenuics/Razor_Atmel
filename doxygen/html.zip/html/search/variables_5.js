var searchData=
[
  ['s8rssi',['s8RSSI',['../structAntExtendedDataType.html#a581d4f64c672d93a6df5c63db075d492',1,'AntExtendedDataType']]],
  ['sextendeddata',['sExtendedData',['../structAntApplicationMsgListType.html#a88dcd4b30d79828f4a9611c948d34601',1,'AntApplicationMsgListType']]]
];
