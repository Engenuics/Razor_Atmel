var searchData=
[
  ['gpiosetup',['GpioSetup',['../eief1-pcb-01_8c.html#af88ea80ebfc22fae790de9dd8db74ce9',1,'GpioSetup(void):&#160;eief1-pcb-01.c'],['../eief1-pcb-01_8h.html#af88ea80ebfc22fae790de9dd8db74ce9',1,'GpioSetup(void):&#160;eief1-pcb-01.c']]]
];
