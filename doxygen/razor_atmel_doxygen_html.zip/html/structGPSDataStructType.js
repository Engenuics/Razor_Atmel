var structGPSDataStructType =
[
    [ "s32Altitude", "structGPSDataStructType.html#ad69b108782034c8447b3170859dc38cf", null ],
    [ "s32Latitude", "structGPSDataStructType.html#a0de063446a1a5297f0b8c80fdf915f23", null ],
    [ "s32Longitude", "structGPSDataStructType.html#aea63954aa2e5ff7ef45f16e75d7c5666", null ],
    [ "strFixStatus", "structGPSDataStructType.html#a277a4e17e1413e55b14f6d9d2445a483", null ],
    [ "strHeading", "structGPSDataStructType.html#a6ce1b7bf7ff908f12e4027de99464d1e", null ],
    [ "strLatitude", "structGPSDataStructType.html#a6e44c2f56eb9dec6038becadc8285644", null ],
    [ "strLongitude", "structGPSDataStructType.html#a74987602fde8d4ec3e70a067b2796555", null ],
    [ "strMSLAltitude", "structGPSDataStructType.html#afae8cc16af12bba4d1839ea43ffdcba5", null ],
    [ "strNumSVsTracking", "structGPSDataStructType.html#a43b2b98c47f337611fcda885d8782f33", null ],
    [ "strNumSVsUsed", "structGPSDataStructType.html#a7ed2b8f338c69b40c43238aa95c192b1", null ],
    [ "strSpeed", "structGPSDataStructType.html#a1c71c913fde9091b414b0ed7e539abe9", null ],
    [ "u32Heading", "structGPSDataStructType.html#abd0701f9bb287af560632b78adf042cf", null ],
    [ "u32Speed", "structGPSDataStructType.html#a7610de8610d05feef97b52070cc8a400", null ],
    [ "u8Dummy", "structGPSDataStructType.html#ae50ae14a8875bf9fd53b2987307ecdfd", null ]
];