var structUbxResponseRecordType =
[
    [ "u32TimeStamp", "structUbxResponseRecordType.html#a5c90495f986004ae8c2cce2f94cc87e9", null ],
    [ "u8Class", "structUbxResponseRecordType.html#a3ca399d6c77521ae0daf977da306cb0d", null ],
    [ "u8Dummy1", "structUbxResponseRecordType.html#ac0689becb13e6beb684e7f6251bc0107", null ],
    [ "u8Dummy2", "structUbxResponseRecordType.html#a53cba09c6d20af2e25eeb89efb20ef06", null ],
    [ "u8MsgID", "structUbxResponseRecordType.html#a9746ef8f2077bc52747d1907191e9f32", null ]
];