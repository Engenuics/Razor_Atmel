var structSspConfigurationType =
[
    [ "eBitOrder", "structSspConfigurationType.html#a449a968bbad5ca0e51f056fccfad74c6", null ],
    [ "eSspMode", "structSspConfigurationType.html#a09d4f2ba8f09a5123ec38f6c5ca2ecba", null ],
    [ "fnSlaveRxFlowCallback", "structSspConfigurationType.html#afaf928a52626f2bb4e9ad503927c3db2", null ],
    [ "fnSlaveTxFlowCallback", "structSspConfigurationType.html#a8945a2ae6ec867eef4212a4f74e777a2", null ],
    [ "pCsGpioAddress", "structSspConfigurationType.html#a2d4fa184a4ad668dfdff08c6b61247e0", null ],
    [ "ppu8RxNextByte", "structSspConfigurationType.html#a53c9884c7bae33b79a958f98fc0549dd", null ],
    [ "pu8RxBufferAddress", "structSspConfigurationType.html#ad78a33f90d38bf231bf0dc0d190016b3", null ],
    [ "SspPeripheral", "structSspConfigurationType.html#abb429baf96e0d96c667f3961ac422ac2", null ],
    [ "u16Pad", "structSspConfigurationType.html#a68819f3424f4827ce8368fed50c2b2c2", null ],
    [ "u16RxBufferSize", "structSspConfigurationType.html#ab7fc4919ed52c499554e6a111ff03385", null ],
    [ "u32CsPin", "structSspConfigurationType.html#a746468875c8fa523de187aa9cba2f375", null ]
];