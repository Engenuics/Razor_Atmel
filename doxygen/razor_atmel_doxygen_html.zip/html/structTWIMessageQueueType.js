var structTwiMessageQueueType =
[
    [ "eDirection", "structTwiMessageQueueType.html#af3f634749f1c92d584f28e52d19d1213", null ],
    [ "eStopType", "structTwiMessageQueueType.html#ab10c800427708ef13e7e0ad6d6c38fcb", null ],
    [ "pu8RxBuffer", "structTwiMessageQueueType.html#a90b4f2c98ae95b888a185b7d842f52b5", null ],
    [ "u32MessageTaskToken", "structTwiMessageQueueType.html#a4e55816ee45cf4fda59e17b4b032dc94", null ],
    [ "u32Size", "structTwiMessageQueueType.html#a1e9d88314667b1ed7c5ab9c3dad6ea4e", null ],
    [ "u8Address", "structTwiMessageQueueType.html#a90a4a09cb07d3a4d61c79d9c14a8e70e", null ],
    [ "u8Pad", "structTwiMessageQueueType.html#a095538a86db156105d1920856af97f8b", null ]
];