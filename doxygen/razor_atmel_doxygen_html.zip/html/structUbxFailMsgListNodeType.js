var structUbxFailMsgListNodeType =
[
    [ "pNextRecord", "structUbxFailMsgListNodeType.html#adaa0fbfc80497961808c27104e5f278c", null ],
    [ "sRecord", "structUbxFailMsgListNodeType.html#af9dd6c569a3aa08f62a223b008b83c60", null ]
];