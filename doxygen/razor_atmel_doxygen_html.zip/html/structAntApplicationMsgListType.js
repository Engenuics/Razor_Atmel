var structAntApplicationMsgListType =
[
    [ "au8MessageData", "structAntApplicationMsgListType.html#aaef1775904a7f6d2ff4421035e789d92", null ],
    [ "eMessageType", "structAntApplicationMsgListType.html#a136ff44aec1d4d02fdaf6ae3cc923878", null ],
    [ "psNextMessage", "structAntApplicationMsgListType.html#a3cf7e0c78f70a803e302a2a3cd2b8baf", null ],
    [ "sExtendedData", "structAntApplicationMsgListType.html#a88dcd4b30d79828f4a9611c948d34601", null ],
    [ "u32TimeStamp", "structAntApplicationMsgListType.html#a5c90495f986004ae8c2cce2f94cc87e9", null ],
    [ "u8Channel", "structAntApplicationMsgListType.html#ab76fdb9425184ad2e069d74de963e98a", null ]
];