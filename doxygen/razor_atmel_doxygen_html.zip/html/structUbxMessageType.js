var structUbxMessageType =
[
    [ "pu8Payload", "structUbxMessageType.html#a31c39bb85c27d406db7b73a10fe164c4", null ],
    [ "u16Length", "structUbxMessageType.html#a9e81ffe8770405ed16cc804c613dee7c", null ],
    [ "u8Class", "structUbxMessageType.html#a3ca399d6c77521ae0daf977da306cb0d", null ],
    [ "u8MsgID", "structUbxMessageType.html#a9746ef8f2077bc52747d1907191e9f32", null ]
];