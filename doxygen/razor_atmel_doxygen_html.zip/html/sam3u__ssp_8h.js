var sam3u__ssp_8h =
[
    [ "SspConfigurationType", "structSspConfigurationType.html", "structSspConfigurationType" ],
    [ "SspPeripheralType", "structSspPeripheralType.html", "structSspPeripheralType" ],
    [ "_SSP_CS_ASSERTED", "sam3u__ssp_8h.html#a61d6a58dd13b0548b2f76d531dd67d07", null ],
    [ "_SSP_ERROR_INVALID_SSP", "sam3u__ssp_8h.html#a06b2252d0c46aeb97550f80a9aeb7c70", null ],
    [ "_SSP_MANUAL_MODE", "sam3u__ssp_8h.html#a8f69badc3cff61349ba7860530c504c1", null ],
    [ "_SSP_PERIPHERAL_ASSIGNED", "sam3u__ssp_8h.html#a800cd81ded8a27bfa9562e43898c810d", null ],
    [ "_SSP_PERIPHERAL_RX", "sam3u__ssp_8h.html#a6bae485092b9c5253449a9acd7cc748d", null ],
    [ "_SSP_PERIPHERAL_RX_COMPLETE", "sam3u__ssp_8h.html#a69ac04b25fe66835fe209b625e284bd2", null ],
    [ "_SSP_PERIPHERAL_TX", "sam3u__ssp_8h.html#a2e6b2350934b801615e41bdeeda82fe4", null ],
    [ "_SSP_RX_COMPLETE", "sam3u__ssp_8h.html#ad895d3f96de268448157b87fce8eecb7", null ],
    [ "_SSP_TX_COMPLETE", "sam3u__ssp_8h.html#a008d6b6a2950a06af6421385a0734841", null ],
    [ "SSP_DUMMY_BYTE", "sam3u__ssp_8h.html#ac14805795f3f26dfb1ca2b814a1ec605", null ],
    [ "SSP_ERROR_FLAG_MASK", "sam3u__ssp_8h.html#ae3c576612cfd64727ddb6bc5fa021dc4", null ],
    [ "SSP_TXEMPTY_TIMEOUT", "sam3u__ssp_8h.html#a6c67e1d247939af196348f56e192c2b4", null ],
    [ "SspBitOrderType", "sam3u__ssp_8h.html#a348e1f3c063e297e9359badeda6b420d", [
      [ "SSP_MSB_FIRST", "sam3u__ssp_8h.html#a348e1f3c063e297e9359badeda6b420da0e9bbabb8eec46875a8f62374a6cfa48", null ],
      [ "SSP_LSB_FIRST", "sam3u__ssp_8h.html#a348e1f3c063e297e9359badeda6b420da8834bdc3a4a400c8299fefd2d64eeebe", null ]
    ] ],
    [ "SspModeType", "sam3u__ssp_8h.html#add58c530ced3f2d039a19d990c5633ac", [
      [ "SSP_MASTER_AUTO_CS", "sam3u__ssp_8h.html#add58c530ced3f2d039a19d990c5633aca9e488f202a5e69bf5d8e8a6052cb0ed2", null ],
      [ "SSP_MASTER_MANUAL_CS", "sam3u__ssp_8h.html#add58c530ced3f2d039a19d990c5633acac6c173c3649f219328b60f6ff13bbeea", null ],
      [ "SSP_SLAVE", "sam3u__ssp_8h.html#add58c530ced3f2d039a19d990c5633acafb66cc9f8a02749a9190f59d80df908b", null ],
      [ "SSP_SLAVE_FLOW_CONTROL", "sam3u__ssp_8h.html#add58c530ced3f2d039a19d990c5633acad0819e17f0b5723231e9e54b927d103b", null ]
    ] ],
    [ "SspRxStatusType", "sam3u__ssp_8h.html#ae06eee04d7c0a6c01a1c9bfc6ff97935", [
      [ "SSP_RX_EMPTY", "sam3u__ssp_8h.html#ae06eee04d7c0a6c01a1c9bfc6ff97935aacead12d48fc75dbeaca8aa7e9d5f8d5", null ],
      [ "SSP_RX_WAITING", "sam3u__ssp_8h.html#ae06eee04d7c0a6c01a1c9bfc6ff97935a8457a7c047ce242b223a59d16ba7e309", null ],
      [ "SSP_RX_RECEIVING", "sam3u__ssp_8h.html#ae06eee04d7c0a6c01a1c9bfc6ff97935a78a28b81a957b73f805775a346b2afa9", null ],
      [ "SSP_RX_COMPLETE", "sam3u__ssp_8h.html#ae06eee04d7c0a6c01a1c9bfc6ff97935a162e5e8724436aed8756e5f574823e95", null ],
      [ "SSP_RX_TIMEOUT", "sam3u__ssp_8h.html#ae06eee04d7c0a6c01a1c9bfc6ff97935a5f3fa9d0a999af8965904c892ab99db7", null ],
      [ "SSP_RX_INVALID", "sam3u__ssp_8h.html#ae06eee04d7c0a6c01a1c9bfc6ff97935ab729671ddbb114320e9bdae5d4216eea", null ]
    ] ],
    [ "SSP0_IRQHandler", "sam3u__ssp_8h.html#a56a77444d4b4985ba292102c14c94ed6", null ],
    [ "SSP1_IRQHandler", "sam3u__ssp_8h.html#a048b2396e2594865c6947b71774e2328", null ],
    [ "SSP2_IRQHandler", "sam3u__ssp_8h.html#acb4bca10e4b89778ebf1e7777c271b89", null ],
    [ "SspAssertCS", "sam3u__ssp_8h.html#ac39e2617abb91eb808b10b8ee76f48e5", null ],
    [ "SspDeAssertCS", "sam3u__ssp_8h.html#a1ebff36daaa4738eb1c54f73bd960fbd", null ],
    [ "SspInitialize", "sam3u__ssp_8h.html#ab99dfbfcd09ea5141571cb32fcfc2168", null ],
    [ "SspManualMode", "sam3u__ssp_8h.html#ac09f4994590d539f80572ad62d364030", null ],
    [ "SspQueryReceiveStatus", "sam3u__ssp_8h.html#af7d1d6a3c3e6c731ec2bf807de9ff193", null ],
    [ "SspReadByte", "sam3u__ssp_8h.html#ab9a0499951b9f06aaf371e3fa0fedc00", null ],
    [ "SspReadData", "sam3u__ssp_8h.html#a8fd02718ad17492d876d661c559504af", null ],
    [ "SspRelease", "sam3u__ssp_8h.html#a798c42a19e4d1f4293f0cf5887416935", null ],
    [ "SspRequest", "sam3u__ssp_8h.html#a3cdfcc15fd8f09f3428cfaf788121a62", null ],
    [ "SspRunActiveState", "sam3u__ssp_8h.html#a9427fc6664d343c7dc3128cf21aba263", null ],
    [ "SspWriteByte", "sam3u__ssp_8h.html#abe25b5b3e6a9c0ef130384ce560dc9b3", null ],
    [ "SspWriteData", "sam3u__ssp_8h.html#ab9b7115e235d10c5e769f00919d2a42b", null ]
];