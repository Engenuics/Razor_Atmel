var structButtonConfigType =
[
    [ "eActiveState", "structButtonConfigType.html#ad53624b8575f2e0e1c97f65107034fd6", null ],
    [ "ePort", "structButtonConfigType.html#a4e1b530ecb157d31073f9e9c4c4a76bf", null ]
];