var NAVTREE =
[
  [ "EiE Firmware", "index.html", [
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Structure Index", "classes.html", null ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", null ],
        [ "Variables", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", "globals_func" ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", null ],
        [ "Macros", "globals_defs.html", "globals_defs" ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"accel__adxl345_8c_source.html",
"antdefines_8h.html#afd5b91b8890e785b79fd22c39d3dee35",
"eief1-pcb-01_8c.html#a786a28c1a4964ca2a3b8af5e8cfde934",
"globals_i.html",
"messaging_8h.html#a9eed4670719ebe069b108b73b69ee4fe",
"sam3u__ssp_8c.html#af7d1d6a3c3e6c731ec2bf807de9ff193",
"structUartPeripheralType.html#a095538a86db156105d1920856af97f8b"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';