var structUbxResponseListNodeType =
[
    [ "pNextRecord", "structUbxResponseListNodeType.html#adaa0fbfc80497961808c27104e5f278c", null ],
    [ "sRecord", "structUbxResponseListNodeType.html#a358c5362ed9a443140b829c3303062fa", null ]
];