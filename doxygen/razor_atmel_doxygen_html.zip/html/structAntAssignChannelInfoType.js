var structAntAssignChannelInfoType =
[
    [ "AntChannel", "structAntAssignChannelInfoType.html#af2f5f85ffc897038613a0913b5b35274", null ],
    [ "AntChannelPeriodHi", "structAntAssignChannelInfoType.html#a34611a4b519aed29f8ed78d5e5922e83", null ],
    [ "AntChannelPeriodLo", "structAntAssignChannelInfoType.html#aa1eca4f34475701931c42afa3a5335ec", null ],
    [ "AntChannelType", "structAntAssignChannelInfoType.html#ae92b3a0d2629876055cbdf1882945368", null ],
    [ "AntDeviceIdHi", "structAntAssignChannelInfoType.html#a6780cf157bcfa6022257c5b74fa3bd24", null ],
    [ "AntDeviceIdLo", "structAntAssignChannelInfoType.html#a5d00fa2d46ceecf638631faca7063c9e", null ],
    [ "AntDeviceType", "structAntAssignChannelInfoType.html#a60f438d458dd185dffeddcd565257934", null ],
    [ "AntFlags", "structAntAssignChannelInfoType.html#a3e5d131df19a0e2b8d78fa30cb61c588", null ],
    [ "AntFrequency", "structAntAssignChannelInfoType.html#ab57149bd1b0741b86eb3b0500d549c8a", null ],
    [ "AntNetwork", "structAntAssignChannelInfoType.html#a2b308d93ddb581dafeddc6695de8a67d", null ],
    [ "AntNetworkKey", "structAntAssignChannelInfoType.html#a6b7651ec1149466d340f347b3febe575", null ],
    [ "AntTransmissionType", "structAntAssignChannelInfoType.html#a29c4fd5398ea2aa93db05d8b39821850", null ],
    [ "AntTxPower", "structAntAssignChannelInfoType.html#a49cde9e5034935cd31b9712162183bb5", null ]
];