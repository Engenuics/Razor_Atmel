var structUbxFailRecordType =
[
    [ "eFailReason", "structUbxFailRecordType.html#a385a3b0897deba459fb721ab40aa199c", null ],
    [ "u8Class", "structUbxFailRecordType.html#a3ca399d6c77521ae0daf977da306cb0d", null ],
    [ "u8MsgID", "structUbxFailRecordType.html#a9746ef8f2077bc52747d1907191e9f32", null ]
];