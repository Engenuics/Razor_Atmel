var sam3u__spi_8c =
[
    [ "SPI0_IrqHandler", "sam3u__spi_8c.html#a649e0c1566b358c4ceef841110102729", null ],
    [ "SpiInitialize", "sam3u__spi_8c.html#aba925e3f2f6db724cc7c658aa2194666", null ],
    [ "SpiManualMode", "sam3u__spi_8c.html#ac2b83008a53b47d3aa3f32c6daa1e526", null ],
    [ "SpiQueryReceiveStatus", "sam3u__spi_8c.html#a53b41283a1472f154684a0bae059c3ae", null ],
    [ "SpiReadByte", "sam3u__spi_8c.html#a4199476ce7e4e7e6053c6c83fd2c8b05", null ],
    [ "SpiReadData", "sam3u__spi_8c.html#a4035042dbf5e554c4711edd370cf8708", null ],
    [ "SpiRelease", "sam3u__spi_8c.html#a2036fe5e9c7a5cd772d7167fa3db221b", null ],
    [ "SpiRequest", "sam3u__spi_8c.html#a3064ef955ce4ae193bc8dc8bf23a86f9", null ],
    [ "SpiRunActiveState", "sam3u__spi_8c.html#a32acf207c4bb9895665793e7d6a78a6e", null ],
    [ "SpiWriteByte", "sam3u__spi_8c.html#a48c914e261ba63bf6f8c0c1b616ca785", null ],
    [ "SpiWriteData", "sam3u__spi_8c.html#a861fb1e714f39349aa1c45a62ca73d92", null ],
    [ "G_u32ApplicationFlags", "sam3u__spi_8c.html#a633c00979917e136ecca6a4c6be2792d", null ],
    [ "G_u32Spi0ApplicationFlags", "sam3u__spi_8c.html#a2748a198a57b374dfbcfe58d9839563b", null ],
    [ "G_u32SystemFlags", "sam3u__spi_8c.html#a8744f5867dbc6c175c029dd7ee5e70af", null ],
    [ "G_u32SystemTime1ms", "sam3u__spi_8c.html#aa146f1e0ff7266bfbef420b6fc072f80", null ],
    [ "G_u32SystemTime1s", "sam3u__spi_8c.html#a0d1ec61cf0423379d45262186ed60d9c", null ]
];