var searchData=
[
  ['peripheraltype',['PeripheralType',['../configuration_8h.html#afc6e623ab05d213bda9b62f3bd823238',1,'configuration.h']]]
];
