var searchData=
[
  ['blade_5fspi_5fflags',['BLADE_SPI_FLAGS',['../configuration_8h.html#a5d3d1fc66635f78e9172eeb7ee0ff229',1,'configuration.h']]]
];
