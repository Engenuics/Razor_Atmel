var searchData=
[
  ['event_5fchannel_5fclosed',['EVENT_CHANNEL_CLOSED',['../antdefines_8h.html#a3c98222b578e07851e5b730ae85fe378',1,'antdefines.h']]],
  ['event_5frx_5ffail',['EVENT_RX_FAIL',['../antdefines_8h.html#ab0b5a170abca54d03a5209c5f7ac4334',1,'antdefines.h']]],
  ['event_5frx_5ffail_5fgo_5fto_5fsearch',['EVENT_RX_FAIL_GO_TO_SEARCH',['../antdefines_8h.html#a316dbf3aceae529c5133265e19631f6c',1,'antdefines.h']]],
  ['event_5frx_5fsearch_5ftimeout',['EVENT_RX_SEARCH_TIMEOUT',['../antdefines_8h.html#a6cf29c8003e4b98fd7626615525a3a26',1,'antdefines.h']]],
  ['event_5ftransfer_5frx_5ffailed',['EVENT_TRANSFER_RX_FAILED',['../antdefines_8h.html#a67034ef4ff4cdb7ed61d47897962db77',1,'antdefines.h']]],
  ['event_5ftransfer_5ftx_5fcompleted',['EVENT_TRANSFER_TX_COMPLETED',['../antdefines_8h.html#a51573152c1529ee27fed45e93372728f',1,'antdefines.h']]],
  ['event_5ftransfer_5ftx_5ffailed',['EVENT_TRANSFER_TX_FAILED',['../antdefines_8h.html#af9f5a3fd4304ebae7e61e6ce78fed2b9',1,'antdefines.h']]],
  ['event_5ftx',['EVENT_TX',['../antdefines_8h.html#a40d241d4c2b75bacb4339156e405f503',1,'antdefines.h']]]
];
