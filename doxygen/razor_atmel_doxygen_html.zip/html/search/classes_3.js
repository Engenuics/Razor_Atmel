var searchData=
[
  ['gpsdatastructtype',['GPSDataStructType',['../structGPSDataStructType.html',1,'']]],
  ['gpssvdatatype',['GPSSVDataType',['../structGPSSVDataType.html',1,'']]]
];
