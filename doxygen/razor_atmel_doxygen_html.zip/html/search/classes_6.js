var searchData=
[
  ['spiconfigurationtype',['SpiConfigurationType',['../structSpiConfigurationType.html',1,'']]],
  ['spiperipheraltype',['SpiPeripheralType',['../structSpiPeripheralType.html',1,'']]],
  ['sspconfigurationtype',['SspConfigurationType',['../structSspConfigurationType.html',1,'']]],
  ['sspperipheraltype',['SspPeripheralType',['../structSspPeripheralType.html',1,'']]]
];
