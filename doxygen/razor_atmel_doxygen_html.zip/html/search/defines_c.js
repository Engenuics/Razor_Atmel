var searchData=
[
  ['number_5fapplications',['NUMBER_APPLICATIONS',['../main_8h.html#ade12517e47f32c03f37f4bf7fb37ca1c',1,'main.h']]],
  ['number_5fascii_5fto_5fdec',['NUMBER_ASCII_TO_DEC',['../utilities_8h.html#aaaa8a025d4b928fe46a24240c7b7b71c',1,'utilities.h']]]
];
