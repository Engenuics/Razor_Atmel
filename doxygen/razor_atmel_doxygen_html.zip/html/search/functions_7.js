var searchData=
[
  ['interruptsetup',['InterruptSetup',['../interrupts_8c.html#a681d9232bd9744d305976f4d505f80b7',1,'InterruptSetup(void):&#160;interrupts.c'],['../interrupts_8h.html#a681d9232bd9744d305976f4d505f80b7',1,'InterruptSetup(void):&#160;interrupts.c']]],
  ['isbuttonheld',['IsButtonHeld',['../buttons_8c.html#a21a66d62c2d9ed5fbe3b48970bffdcc7',1,'IsButtonHeld(u32 u32Button_, u32 u32ButtonHeldTime_):&#160;buttons.c'],['../buttons_8h.html#a21a66d62c2d9ed5fbe3b48970bffdcc7',1,'IsButtonHeld(u32 u32Button_, u32 u32ButtonHeldTime_):&#160;buttons.c']]],
  ['isbuttonpressed',['IsButtonPressed',['../buttons_8c.html#aa04cd1cc8225f76a2344ca1a919a25d0',1,'IsButtonPressed(u32 u32Button_):&#160;buttons.c'],['../buttons_8h.html#aa04cd1cc8225f76a2344ca1a919a25d0',1,'IsButtonPressed(u32 u32Button_):&#160;buttons.c']]],
  ['istimeup',['IsTimeUp',['../utilities_8c.html#ac24b2bf21f8999181cded7b450749dea',1,'IsTimeUp(u32 *pu32SavedTick_, u32 u32Period_):&#160;utilities.c'],['../utilities_8h.html#ac24b2bf21f8999181cded7b450749dea',1,'IsTimeUp(u32 *pu32SavedTick_, u32 u32Period_):&#160;utilities.c']]]
];
