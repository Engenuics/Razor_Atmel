var searchData=
[
  ['osc_5fvalue',['OSC_VALUE',['../eief1-pcb-01_8h.html#a02682feb445d88186d6d40048f85ae88',1,'eief1-pcb-01.h']]]
];
