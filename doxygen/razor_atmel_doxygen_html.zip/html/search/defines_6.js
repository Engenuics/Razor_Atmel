var searchData=
[
  ['firmware_5fmain_5frev',['FIRMWARE_MAIN_REV',['../main_8h.html#a5670ed052b79d0f8b2ac103790453a5f',1,'main.h']]]
];
