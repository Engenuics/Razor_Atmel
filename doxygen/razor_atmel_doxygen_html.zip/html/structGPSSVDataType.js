var structGPSSVDataType =
[
    [ "u8CNo", "structGPSSVDataType.html#ade289b957dba80f57c9584256c5d55ac", null ],
    [ "u8SVID", "structGPSSVDataType.html#a040cb083fbecc76d20cda818dd546c0e", null ]
];