var structSspPeripheralType =
[
    [ "eBitOrder", "structSspPeripheralType.html#a449a968bbad5ca0e51f056fccfad74c6", null ],
    [ "eSspMode", "structSspPeripheralType.html#a09d4f2ba8f09a5123ec38f6c5ca2ecba", null ],
    [ "fnSlaveRxFlowCallback", "structSspPeripheralType.html#afaf928a52626f2bb4e9ad503927c3db2", null ],
    [ "fnSlaveTxFlowCallback", "structSspPeripheralType.html#a8945a2ae6ec867eef4212a4f74e777a2", null ],
    [ "pBaseAddress", "structSspPeripheralType.html#a8114fd7dd814a2dc4b585e7d4ebd4922", null ],
    [ "pCsGpioAddress", "structSspPeripheralType.html#a2d4fa184a4ad668dfdff08c6b61247e0", null ],
    [ "ppu8RxNextByte", "structSspPeripheralType.html#a53c9884c7bae33b79a958f98fc0549dd", null ],
    [ "psTransmitBuffer", "structSspPeripheralType.html#ab050493c2ee33d0b4525999076d8bbe6", null ],
    [ "pu8CurrentTxData", "structSspPeripheralType.html#a37d6782344fe4a6866def37b345f3361", null ],
    [ "pu8RxBuffer", "structSspPeripheralType.html#a90b4f2c98ae95b888a185b7d842f52b5", null ],
    [ "u16Pad", "structSspPeripheralType.html#a68819f3424f4827ce8368fed50c2b2c2", null ],
    [ "u16RxBufferSize", "structSspPeripheralType.html#ab7fc4919ed52c499554e6a111ff03385", null ],
    [ "u16RxBytes", "structSspPeripheralType.html#ab68f3ebf343dd380a0394c213eb653f4", null ],
    [ "u32CsPin", "structSspPeripheralType.html#a746468875c8fa523de187aa9cba2f375", null ],
    [ "u32CurrentTxBytesRemaining", "structSspPeripheralType.html#aba7dde0373af6515f1ea1fb3ca60b0b7", null ],
    [ "u32PrivateFlags", "structSspPeripheralType.html#a92ea6e492759d5d2e4b46c21ed300e4c", null ],
    [ "u8Pad", "structSspPeripheralType.html#a095538a86db156105d1920856af97f8b", null ],
    [ "u8PeripheralId", "structSspPeripheralType.html#a6d47610e17bac3adaae644e2f1abd6ce", null ]
];