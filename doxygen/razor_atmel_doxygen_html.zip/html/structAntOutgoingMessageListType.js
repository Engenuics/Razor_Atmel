var structAntOutgoingMessageListType =
[
    [ "au8MessageData", "structAntOutgoingMessageListType.html#a44e4df9119169a320aa6f3487e693dd3", null ],
    [ "psNextMessage", "structAntOutgoingMessageListType.html#a3cf7e0c78f70a803e302a2a3cd2b8baf", null ],
    [ "u32TimeStamp", "structAntOutgoingMessageListType.html#a5c90495f986004ae8c2cce2f94cc87e9", null ]
];